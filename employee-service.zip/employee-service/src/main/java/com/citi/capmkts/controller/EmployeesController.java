package com.citi.capmkts.controller;

import com.citi.capmkts.model.Employee;
import com.citi.capmkts.repo.EmployeesRepository;
import com.citi.capmkts.service.EmployeesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class EmployeesController {


    @Autowired
    EmployeesService employeesService;

    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> getAllEmployees(@RequestParam(required = false) String empName) {
        return new ResponseEntity<>(employeesService.getAllEmployees(empName), HttpStatus.OK);

    }

    @GetMapping("/employees/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") long id) {
        Optional<Employee> employeeOptional = employeesService.getEmployeeById(id);
        return employeeOptional.map(employee -> new ResponseEntity<>(employee, HttpStatus.OK)).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/employees")
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        Employee employee1 = employeesService.createEmployee(new Employee(employee.getId(), employee.getEmpName(), employee.getDepartment(), employee.getLocation(), employee.isEmployeeFlag()));
        return new ResponseEntity<>(employee1, HttpStatus.CREATED);

    }

    @PutMapping("/employees/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable("id") long id, @RequestBody Employee employee) {

            return new ResponseEntity<>(employeesService.updateEmployee(id, employee), HttpStatus.OK);

    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<HttpStatus> deleteEmployee(@PathVariable("id") long id) {
        try {
            employeesService.deleteEmployee(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/employees/active-employees")
    public ResponseEntity<List<Employee>> findByActiveEmployees() {
        try {
            return new ResponseEntity<>(employeesService.findActiveEmployees(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
