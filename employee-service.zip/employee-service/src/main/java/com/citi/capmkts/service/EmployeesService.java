package com.citi.capmkts.service;

import com.citi.capmkts.exception.EmployeeServiceException;
import com.citi.capmkts.exception.RecordNotFoundException;
import com.citi.capmkts.model.Employee;
import com.citi.capmkts.repo.EmployeesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeesService {

    @Autowired
    EmployeesRepository employeesRepository;

    public List<Employee> getAllEmployees(String empName) {
        try {
            List<Employee> employees = new ArrayList<Employee>();

            if (empName == null) employees.addAll(employeesRepository.findAll());
            else employees.addAll(employeesRepository.findByEmpNameContainingIgnoreCase(empName));

            if (employees.isEmpty()) {
                throw new RecordNotFoundException("No data found");
            }
            return employees;
        } catch (Exception e) {
            throw new EmployeeServiceException("Internal Server Error", e.getMessage());
        }
    }

    public Optional<Employee> getEmployeeById(long id) {
        return employeesRepository.findById(id);
    }

    public Employee createEmployee(Employee employee) {
        try {
            return employeesRepository.save(new Employee(employee.getId(), employee.getEmpName(), employee.getDepartment(), employee.getLocation(), employee.isEmployeeFlag()));
        } catch (Exception e) {
            throw new EmployeeServiceException("Internal Server Error", e.getMessage());
        }
    }

    public Employee updateEmployee(long id, Employee employee) {
        Optional<Employee> employeeData = employeesRepository.findById(id);
        if (employeeData.isPresent()) {
            Employee employee1 = employeeData.get();
            employee1.setEmpName(employee.getEmpName());
            employee1.setDepartment(employee.getDepartment());
            employee1.setLocation(employee.getLocation());
            employee1.setEmployeeFlag(employee.isEmployeeFlag());
            return employeesRepository.save(employee1);
        } else {
            throw new RecordNotFoundException("No data found");
        }
    }

    public void deleteEmployee(long id) {
        try {
            employeesRepository.deleteById(id);
        } catch (Exception e) {
            throw new EmployeeServiceException("Internal Server Error", e.getMessage());
        }
    }

    public List<Employee> findActiveEmployees(){
        try {
            List<Employee> employees = employeesRepository.findByEmployeeFlag(true);

            if (employees.isEmpty()) {
                throw new RecordNotFoundException("No data found");
            }
            return employees;
        } catch (Exception e) {
            throw new EmployeeServiceException("Internal Server Error", e.getMessage());
        }
    }
}
