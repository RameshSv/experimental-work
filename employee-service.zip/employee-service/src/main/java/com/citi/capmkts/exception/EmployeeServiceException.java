package com.citi.capmkts.exception;

public class EmployeeServiceException extends RuntimeException {

    private String exception;

    private String message;

    public EmployeeServiceException(String exception) {
        super(exception);
    }

    public EmployeeServiceException(String exception, String message){
        this.exception = exception;
        this.message = message;
    }

}