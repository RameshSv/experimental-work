package com.citi.capmkts.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Table(name = "employees")
@Data
@AllArgsConstructor
public class Employee {

    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "emp_name")
    private String empName;

    @Column(name = "location")
    private String location;

    @Column(name = "department")
    private String department;

    @Column(name = "active_emp_flag")
    private boolean employeeFlag;
}
