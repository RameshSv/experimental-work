package com.citi.capmkts.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.List;

@RestControllerAdvice
public class EmployeeControllerAdvice {

    @ExceptionHandler(RecordNotFoundException.class)
    public ResponseEntity<Object> handleNoRecordFound(RecordNotFoundException ex, WebRequest request) {
        return new ResponseEntity<>("No data: " + ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(EmployeeServiceException.class)
    public ResponseEntity<Object> handleInternalServiceException(EmployeeServiceException ex, WebRequest request) {
        return new ResponseEntity<>(ex.getCause() + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleUnknownError(Exception ex, WebRequest request) {
        return new ResponseEntity<>(ex.getCause() + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }


}